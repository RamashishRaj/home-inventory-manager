# README #

Home Inventory Manager is a web application I built in anticipation of moving to a new house. No inventory managers did what I needed so I built my own. Built with Angular.

### Details ###

* Uses Angular
* Version 0.1


### Setup ###

1. Run npm install
2. Run bower install

### Startup ###
1. Run npm start

### Questions? ###

* Contact [Stephen da Conceicao](mailto:stephen@stephenandrewdesigns.com)