const uri = {
    api: "http://defiant:1337/api"
};

module.exports = uri;
