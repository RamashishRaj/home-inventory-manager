/* global module, require */
'use strict';

const oath = {
    facebookId: 1161964343837049
};

module.exports = oath;
